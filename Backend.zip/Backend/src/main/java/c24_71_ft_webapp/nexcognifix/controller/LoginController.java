package c24_71_ft_webapp.nexcognifix.controller;

import c24_71_ft_webapp.nexcognifix.domain.professional.DataLoginProfessional;
import c24_71_ft_webapp.nexcognifix.domain.professional.Professional;
import c24_71_ft_webapp.nexcognifix.infrastructure.security.DataJWTToken;
import c24_71_ft_webapp.nexcognifix.infrastructure.security.TokenService;
import jakarta.annotation.PostConstruct;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping("/login")
public class LoginController {

        @Autowired
        private TokenService tokenService;

        @Autowired
        private AuthenticationManager authenticationManager;

    @PostConstruct
    public void init() {
        System.out.println("🚀 LoginController cargado correctamente");
    }

    @PostMapping
    public ResponseEntity<String> autenticateUser(@RequestBody DataLoginProfessional dataLoginProfessional) {
        System.out.println("Intentando autenticar usuario: " + dataLoginProfessional.email());

        Authentication authToken = new UsernamePasswordAuthenticationToken(
                dataLoginProfessional.email(), dataLoginProfessional.password());

        var userAuth = authenticationManager.authenticate(authToken);

        if (userAuth.isAuthenticated()) {
            System.out.println("Autenticación exitosa para: " + dataLoginProfessional.email());
            return ResponseEntity.ok("Acceso permitido");
        } else {
            System.out.println("Autenticación fallida para: " + dataLoginProfessional.email());
            return ResponseEntity.status(401).body("Acceso denegado");
        }
    }

//    @PostMapping
//    public ResponseEntity autenticarUsuario(@RequestBody @Valid DataLoginProfessional dataLoginProfessional) {
//        System.out.println("Intentando autenticar al usuario: " + dataLoginProfessional.email());
//
//        Authentication authToken = new UsernamePasswordAuthenticationToken(
//                dataLoginProfessional.email(), dataLoginProfessional.password());
//
//        var userAuth = authenticationManager.authenticate(authToken);
//
//        var JWTtoken = tokenService.generateToken((Professional) userAuth.getPrincipal());
//
//        System.out.println("Autenticación exitosa para: " + dataLoginProfessional.email());
//
//        return ResponseEntity.ok(new DataJWTToken(JWTtoken));
//    }

}
