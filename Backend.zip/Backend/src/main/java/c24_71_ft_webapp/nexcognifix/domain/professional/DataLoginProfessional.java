package c24_71_ft_webapp.nexcognifix.domain.professional;

public record DataLoginProfessional(
        String email,
        String password
) {
}
