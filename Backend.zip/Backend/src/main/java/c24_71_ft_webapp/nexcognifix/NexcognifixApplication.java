package c24_71_ft_webapp.nexcognifix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NexcognifixApplication {

	public static void main(String[] args) {
		SpringApplication.run(NexcognifixApplication.class, args);
	}

}
