package c24_71_ft_webapp.nexcognifix.infrastructure.security;

import c24_71_ft_webapp.nexcognifix.domain.professional.ProfessionalRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;

@Component
public class SecurityFilter extends OncePerRequestFilter {

    @Autowired
    private TokenService tokenService;

    @Autowired
    private ProfessionalRepository professionalRepository;




    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        var authHeader = request.getHeader("Authorization");
        System.out.println("Authorization Header: " + authHeader);
        if (authHeader != null && authHeader.trim().startsWith("Bearer ")) {
            var token = authHeader.trim().replace("Bearer ", "");
            System.out.println("Extracted Token: " + token);
            var subject = tokenService.getSubject(token);
            System.out.println("Decoded subject (email): " + subject);
            if (subject == null) {
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                response.getWriter().write("Token inválido o expirado.");
                return;
            }

            var userOptional = professionalRepository.findByEmail(subject);
            if (userOptional.isPresent()) {
                var user = userOptional.get();
                System.out.println("Usuario encontrado: " + user.getEmail());
                var authentication = new UsernamePasswordAuthenticationToken(user, null, user.getAuthorities());
                System.out.println("Authorities: " + user.getAuthorities());
//                SecurityContextHolder.getContext().setAuthentication(authentication);
                System.out.println("Antes de setAuthentication: " + SecurityContextHolder.getContext().getAuthentication());
                SecurityContextHolder.getContext().setAuthentication(authentication);
                System.out.println("Después de setAuthentication: " + SecurityContextHolder.getContext().getAuthentication());

            } else {
                System.out.println("Usuario no encontrado para el token: " + subject);
            }
        }

        filterChain.doFilter(request, response);
    }
}
