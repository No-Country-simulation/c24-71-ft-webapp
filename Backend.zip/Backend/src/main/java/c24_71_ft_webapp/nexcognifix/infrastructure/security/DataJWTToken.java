package c24_71_ft_webapp.nexcognifix.infrastructure.security;

public record DataJWTToken(String jwTtoken) {
}
