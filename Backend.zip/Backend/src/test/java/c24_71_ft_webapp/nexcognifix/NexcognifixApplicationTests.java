package c24_71_ft_webapp.nexcognifix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NexcognifixApplicationTests {

	@Test
	void contextLoads() {
	}

}
